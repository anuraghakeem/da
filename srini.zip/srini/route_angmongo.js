var express = require('express');  
var bodyParser = require('body-parser'); 
var ejs = require('ejs');
var MongoClient = require('mongodb').MongoClient;
var app = express();  
var urlencodedParser = bodyParser.urlencoded({ extended: false })
// Connect to the db

MongoClient.connect("mongodb://127.0.0.1/retail_store", function(err, db) {
 if(!err) {
    console.log("We are connected");

app.use(express.static('public')); //making public directory as static directory  
app.use(bodyParser.json());
app.get('/', function (req, res) {  
   res.sendFile( __dirname + "/" + "index.html" );  
})
/*JS client side files has to be placed under a folder by name 'public' */



/* to access the posted data from client using request body (POST) or request params(GET) */
//-----------------------POST METHOD-------------------------------------------------
app.post('/process_post', function (req, res) {
    /* Handling the AngularJS post request*/
    console.log(req.body);
	res.setHeader('Content-Type', 'text/html');
		// Submit to the DB
  	var item = Number(req.body.item_name);
    	var cat = req.body.item_cat;
    	var price = req.body.item_price ;
    	var stock = req.body.item_stock ;
	db.collection('item_details').insert({item_name:item, item_cat: cat, item_price: price, item_stock:stock});
    res.end("Item Inserted-->"+JSON.stringify(req.body));
    /*Sending the respone back to the angular Client */
});

//--------------UPDATE------------------------------------------
app.get("/update", function(req, res) {
	var item=Number(req.query.existing_item_name);
	var new_item = Number(req.query.new_item_name);
	var cat = req.query.new_item_category
	var price = req.query.new_item_price
	var stock = req.query.new_item_stock
	console.log( item) ;
	console.log( new_item) ;
	console.log( cat) ;
	console.log( price) ;
	console.log( stock) ;
	console.log( req.query)
	obj = {}
	if ( new_item != "NA" ){
		obj["item_name"] = new_item ;
	}
	if ( cat != "NA" ){
		obj["item_cat"] = cat ;
	}
	if ( price != "NA") {
		obj["item_price"] = price ;
	}
	if ( stock != "NA" ){
		obj["item_stock"] = stock ;
	}
	console.log(obj) ;
 
	db.collection('item_details', function (err, data) {
        data.update({"item_name":item},{$set:obj},{multi:true},
            function(err, result){
				if (err) {
					console.log("Failed to update data.");
			} else {
				res.send(result);
				console.log("Item updated.")
			}
        });
    });
})	
//---------------SEARCH----------------------------------------

app.get("/search", function(req, res) {
	//var empidnum=parseInt(req.query.empid)  // if empid is an integer
	var empidnum=Number(req.query.item_name);
    db.collection('item_details').find({item_name: { $gt: empidnum }}).toArray(function(err, docs) 
//db.collection.find( { qty: { $gt: 4 } } )
    // db.collection('item_details').find({item_name: empidnum}).toArray(function(err, docs) 
{
console.log(docs);
    if (err) {
      console.log(err.message+ "Failed to get data.");
    } else {
      res.status(200).json(docs);
    }
  });
  });

//--------------DELETE------------------------------------------
app.post("/delete", function(req, res) {
	//var empidnum=parseInt(req.query.empid)  // if empid is an integer
	var item =Number(req.body.item_name);
	console.log(item)
	db.collection('item_details', function (err, data) {
        data.remove({"item_name": item}, function(err, result){
				if (err) {
					console.log("Failed to remove data.");
			} else {
				//res.send(result);
				console.log("Item Deleted")
			}
        });
    });
    
  });
app.get('/display', function (req, res) { 
//-----DISPLAY IN JSON FORMAT  -------------------------
db.collection('item_details').find({}).toArray(function(err, docs) {
    if (err) {
      console.log("Failed to get data.");
    } else 
	{
		console.log("Objects :- ")
		console.log(docs);
		res.status(200).json(docs);
    }
  });

}) 
app.get('/about', function (req, res) {  
   console.log("Got a GET request for /about");  
   res.send('MSRIT, Dept. of CSE');  
})  
 
var server = app.listen(5036, function () {  
var host = server.address().address  
  var port = server.address().port  
console.log("Example app listening at http://%s:%s", host, port)  
})  
}
else
{   
	console.log("Database error!") ;
	db.close();  }
  
});
